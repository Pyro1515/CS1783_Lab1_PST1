
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package checkersmain;

import java.util.Scanner;

/**
 *
 * @author Adam A
 * @author Chris S
 */
public class CheckersMain {

    /**
     * @param args the command line arguments
     */
    static int turnCount = 1;
    
    public static void main(String[] args) {
        Board gameBoard = new Board();
        boolean gameStatus = true;
        
        System.out.println("===================");
        System.out.println("WELCOME TO CHECKERS");
        System.out.println("===================");
        
        gameBoard.printBoard(); 
        
        //loop while game is still active
        while(gameBoard.blkCaps != 12 && gameBoard.whtCaps != 12)
        {
            //call method to get input and validate the input
            String input = getAndCheckInput(gameBoard);
            
            
            if(input != null)
            {
                if(input.charAt(0) == 'Q'){
                break;
                }
                
                //if the move is valide change turn and print the refreshed board
                if(gameBoard.validateMove(input, turnCount)){
                    turnCount++;
                    gameBoard.printBoard();
                }else{
                    System.out.println("Invalid move, try again.");
                }
            }
        }
        
        System.out.println("===================");
        System.out.println("The Game has ended.");
        System.out.println("===================");
        // TODO code application logic here
    }
    
    //get input and check that it is valid format
    private static String getAndCheckInput(Board gameBoard){
       Board tempBoard = gameBoard;
       
       //scanner to read in user input
       Scanner readIn = new Scanner(System.in);
       String input;
       String[] stringArr;
       char player = ' ';
       int orig, intend = 0;
       int loopagain;
       
       //loop until valid input is entered
        do{
            loopagain = 1;
            
            //print which player should be entering a move
            if(turnCount % 2 == 1){
                System.out.println("Black enter you're move (Eg:B,12,16): ");
            }else{
                System.out.println("White enter you're move (Eg:W,19,15): ");
            }
            input = readIn.nextLine();
            if(input.charAt(0) == 'q' || input.charAt(0) == 'Q'){
                return "Q";
            }
            
            
            
            //check to make sure that the first comma is in the right place
            if(input.charAt(1) != ',')
            {
                System.out.println("Incorrect Input wrong format");
                loopagain = 0;
                return null;
            }

            //split input into 3 parts
            stringArr = input.split(",");
            
            //check to see that the input starts with a character
            if(Character.isLetter(input.charAt(0)))
            {
                player = stringArr[0].charAt(0);
                player = Character.toUpperCase(player);
                
            }
            
            //if the first character isn't W or B then invalid selection
            if(player != 'W' && player != 'B')
            {
                System.out.println("Player select error");
                loopagain = 0;
                return null;
            }else{
                //makes sure the proper player is moving
                if(turnCount % 2 == 1 && player != 'B'){
                    System.out.println("Attempted move out of turn.");
                    return null;
                }
                if(turnCount % 2 == 0 && player != 'W'){
                    System.out.println("Attempted move out of turn.");
                    return null;
                }
            }
            
            //checks that there are numbers entered at the appropriate places
            if(Character.isDigit(stringArr[1].charAt(0)) && Character.isDigit(stringArr[2].charAt(0)))
            {
                orig = Integer.parseInt(stringArr[1]);
                intend = Integer.parseInt(stringArr[2]);
            }else{
                System.out.println("Format error");
                return null;
            }
            
            //if more than 2 commas are entered, make a double jump
            if(stringArr.length > 3){
                if(intend > orig + 5 || intend < orig - 5){
                    String temp = player + "," + stringArr[1] + "," + stringArr[2];
                    tempBoard.validateMove(temp, turnCount);
                    return player + "," + stringArr[2] + "," + stringArr[3];
                }else{
                    System.out.println("Attempting too many moves.");
                    return null;
                }
            }
            
            //if the string is too long and not a double jump, print error
            if(input.length() > 7)
            {
                System.out.println("Incorrect Input too long");
                System.out.println("If attempting to jump more than once, enter values"
                                + "\n as two seperate single jumps.");
                loopagain = 0;
                return null;
            }
            
            //make sure the locations moving from is a valid board space
            if(!tempBoard.isBoardSpace(orig))
            {
                System.out.println("From location error");
                loopagain = 0;
                return null;
            }
            
            //make sure the location moving to is a valid board space
            if(!tempBoard.isBoardSpace(intend))
            {
                 System.out.println("to location error");
                 loopagain = 0;
                 return null;
            }
            
            }while(loopagain < 0);
       
    //return string with last input used.
    return input;
    }

}
