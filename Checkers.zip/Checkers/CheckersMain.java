
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package checkersmain;

import java.util.Scanner;

/**
 *
 * @author aquat
 */
public class CheckersMain {

    /**
     * @param args the command line arguments
     */
    static int turnCount = 1;
    
    public static void main(String[] args) {
        Board gameBoard = new Board();
        boolean gameStatus = true;
        
        System.out.println("===================");
        System.out.println("WELCOME TO CHECKERS");
        System.out.println("===================");
        
        gameBoard.printBoard(); 
        
        while(gameBoard.blkCaps != 12 && gameBoard.whtCaps != 12)
        {
            String input = getAndCheckInput();
            
            if(input.charAt(0) == 'Q'){
                break;
            }
            if(input != null)
            {
                if(gameBoard.validateMove(input, turnCount)){
                    turnCount++;
                    gameBoard.printBoard();
                }else{
                    System.out.println("Invalid move, try again.");
                }
            }
        }
        
        System.out.println("===================");
        System.out.println("The Game has ended.");
        System.out.println("===================");
        // TODO code application logic here
    }
    
    private static String getAndCheckInput(){
       Board tempBoard = new Board();
       Scanner readIn = new Scanner(System.in);
       String input;
       String[] stringArr;
       char player;
       int orig, intend;
       int loopagain;
       
        do{
            loopagain = 1;
            
            if(turnCount % 2 == 1){
                System.out.println("Black enter you're move (Eg:B,12,16): ");
            }else{
                System.out.println("White enter you're move (Eg:W,19,15): ");
            }
            input = readIn.nextLine();
            if(input.charAt(0) == 'q' || input.charAt(0) == 'Q'){
                return "Q";
            }
            
            
       
            if(input.charAt(1) != ',')
            {
                System.out.println("Incorrect Input wrong format");
                loopagain = 0;
                return null;
            }
            
            if(input.length() > 7)
            {
                System.out.println("Incorrect Input too long");
                System.out.println("If attempting to jump more than once, enter values"
                                + "\n as two seperate single jumps.");
                loopagain = 0;
                return null;
            }
            
            stringArr = input.split(",");
            
            player = ' ';
            orig = 0;
            intend = 0;
            
            if(Character.isLetter(input.charAt(0)))
            {
                player = stringArr[0].charAt(0);
                player = Character.toUpperCase(player);
                
            }
            
            if(Character.isDigit(input.charAt(2)))
            {
                orig = Integer.parseInt(stringArr[1]);
                intend = Integer.parseInt(stringArr[2]);
            }
            
            if(player != 'W' && player != 'B')
            {
                System.out.println("Player select error");
                loopagain = 0;
                return null;
            }else{
                if(turnCount % 2 == 1 && player != 'B'){
                    System.out.println("Attempted move out of turn.");
                    return null;
                }
                if(turnCount % 2 == 0 && player != 'W'){
                    System.out.println("Attempted move out of turn.");
                    return null;
                }
            }
            if(!tempBoard.isBoardSpace(orig))
            {
                System.out.println("From location error");
                loopagain = 0;
                return null;
            }
            if(!tempBoard.isBoardSpace(intend))
            {
                 System.out.println("to location error");
                 loopagain = 0;
                 return null;
            }
            
            }while(loopagain < 0);
       
    return input;
    }

}
