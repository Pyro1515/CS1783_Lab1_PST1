/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package checkersmain;

/**
 *
 * @author aquat
 */
public class CustomIndex {

    private final int first;
    private final int second;
    
    public CustomIndex(int row,int column) {
        this.first = row;
        this.second = column;
    }
    
    public int getFirst(){
        return this.first;
    }
    
    public int getSecond(){
        return this.second;
    }
    
}
