To run, extract the 'Checkers' folder to a location you will remember.
Then open cmd or terminal and navigate to the checkers folder.
Then type 'javac *.java' to compile all files inside.
Finally, type 'java CheckersMain' to run the simulation.